# constants.py

# --- Configuration & Constants ---
# Max range for A320/A321 aircraft (in km)
AIRCRAFT_MAX_RANGE_KM = 6000
MIN_FLIGHT_DISTANCE_KM = 200

# List of countries Indigo flies to or might consider for expansion
RELEVANT_COUNTRIES = [
    'IN', # India (primary)
    'AE', 'TH', 'SG', 'MY', 'BD', 'NP', 'LK', 'MV', # SE Asia & Middle East (current focus)
    'TR', 'QA', 'SA', 'OM', 'KW', # More Middle East
    'VN', 'KH', 'ID', # More SE Asia
    'GR', 'GB', 'NL', 'DK', 'FR', 'DE', 'IT', 'CH', 'AT', 'BE', 'ES' # Recent/future long-haul (A321XLR/A350)
]

# Assumed Indigo Hubs (strategic starting points for new routes)
INDIGO_HUBS_IATA = ['DEL', 'BOM', 'BLR', 'MAA', 'CCU', 'HYD', 'AMD', 'PNQ']

# Simulated City Demand Scores (higher means more demand)
CITY_DEMAND_SCORES = {
    'Delhi': 100, 'Mumbai': 95, 'Bengaluru': 90, 'Chennai': 85, 'Kolkata': 80,
    'Hyderabad': 75, 'Goa': 70, 'Kochi': 65, 'Ahmedabad': 60, 'Lucknow': 55,
    'Pune': 58, 'Jaipur': 52, 'Amritsar': 50, 'Thiruvananthapuram': 60,
    'Dubai': 90, 'Bangkok': 85, 'Singapore': 80, 'Colombo': 50, 'Kathmandu': 45,
    'Male': 60, 'Dhaka': 50, 'Istanbul': 70, 'London': 95, 'Amsterdam': 80,
    'Copenhagen': 70, 'Paris': 90, 'Frankfurt': 85, 'Rome': 75, 'Zurich': 70,
    'Doha': 68, 'Jeddah': 65, 'Muscat': 62, 'Kuwait City': 60,
    'Hanoi': 55, 'Phnom Penh': 40, 'Denpasar': 60 # Bali
}

# Thresholds for recommending a route
DEMAND_THRESHOLD_FOR_RECOMMENDATION = 140
MIN_PROFITABILITY_SCORE_FOR_RECOMMENDATION = 10

# Flight Simulation Parameters
MIN_FLIGHTS_PER_WEEK = 3
MAX_FLIGHTS_PER_WEEK = 14
BASE_PRICE_PER_KM = 0.08
PRICE_VARIANCE_PERCENT = 0.30

# Assumed Congested Airports for Capacity Check
CONGESTED_AIRPORTS_IATA = ['DEL', 'BOM', 'DXB', 'LHR', 'SIN', 'CDG', 'AMS']