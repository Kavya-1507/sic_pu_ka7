1. PROJECT TITLE :
Indigo Airline Routes 


2.PROJECT DESCRIPTION :

An airline route analysis tool for Indigo, identifying new potential routes based on demand, profitability, and competition, visualized on an interactive map with flight simulations .


3.INSTRUCTIONS TO RUN THE CODE :
- Cloning and navigating to the project directory 

-Create a virtual environment : [command : python -m venv venv]

-Activate the Virtual Environment:

    Windows:  .\venv\Scripts\activate

    macOS/Linux: source venv/bin/activate

4. Install the dependencies :
   command :
       pip install -r assets.txt


5. Run the application :
    command :
      python main_app.py

### YOU CAN SEE USE THE html FILE IN YOUR BROWSER TO SEE THE MAP . THE FILE IN PRESENT IN indigo_new_routes_map ###