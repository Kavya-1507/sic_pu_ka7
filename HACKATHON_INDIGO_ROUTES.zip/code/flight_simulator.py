# flight_simulator.py
import random
from constants import MIN_FLIGHTS_PER_WEEK, MAX_FLIGHTS_PER_WEEK, BASE_PRICE_PER_KM, PRICE_VARIANCE_PERCENT # Import constants

def simulate_flights_for_route(origin_city, dest_city, distance_km):
    """
    Simulates a set of hypothetical flights for a given route.
    Generates frequency, specific departure times, and estimated prices.
    """
    flights = []
    num_flights_weekly = random.randint(MIN_FLIGHTS_PER_WEEK, MAX_FLIGHTS_PER_WEEK)
    weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    
    for _ in range(num_flights_weekly):
        day_of_week = random.choice(weekdays)
        hour = random.randint(6, 22)
        minute = random.choice([0, 15, 30, 45])
        departure_time_str = f"{hour:02d}:{minute:02d}"
        flight_duration_minutes = max(60, int((distance_km / 800) * 60) + 30)
        
        base_fare = distance_km * BASE_PRICE_PER_KM
        price = base_fare * (1 + random.uniform(-PRICE_VARIANCE_PERCENT, PRICE_VARIANCE_PERCENT))
        
        flights.append({
            'day': day_of_week,
            'departure_time': departure_time_str,
            'duration_min': flight_duration_minutes,
            'estimated_price_inr': round(price, 0)
        })
    return flights