# main_app.py

import pandas as pd
import folium
import sys

# Import from your new structured files
from constants import (
    AIRCRAFT_MAX_RANGE_KM, MIN_FLIGHT_DISTANCE_KM, INDIGO_HUBS_IATA,
    DEMAND_THRESHOLD_FOR_RECOMMENDATION, MIN_PROFITABILITY_SCORE_FOR_RECOMMENDATION
)
from airports_data import load_and_clean_airports
from geospatial_calcs import haversine
from demand_profit_calcs import get_route_demand_score, calculate_profitability_score
from competition_capacity_checks import assess_competition_level, check_airport_capacity
from flight_simulator import simulate_flights_for_route


def main():
    # 2. Data Loading and Preprocessing
    airports_clean_df = load_and_clean_airports()

    # 4. Generate & Evaluate Potential New Routes
    print("\nGenerating and evaluating potential new routes...")
    potential_new_routes = []

    for idx_orig, orig_airport in airports_clean_df.iterrows():
        if orig_airport['iata_code'] not in INDIGO_HUBS_IATA:
            continue

        if not check_airport_capacity(orig_airport['iata_code']):
            continue

        for idx_dest, dest_airport in airports_clean_df.iterrows():
            if orig_airport['iata_code'] == dest_airport['iata_code']:
                continue

            # Avoid processing duplicate market pairs (e.g., DEL-BOM and BOM-DEL)
            already_added = False
            for r in potential_new_routes:
                if (r['origin_iata'] == dest_airport['iata_code'] and r['destination_iata'] == orig_airport['iata_code']):
                    already_added = True
                    break
            if already_added:
                continue
                
            distance = haversine(orig_airport['latitude_deg'], orig_airport['longitude_deg'],
                                 dest_airport['latitude_deg'], dest_airport['longitude_deg'])

            if not (MIN_FLIGHT_DISTANCE_KM < distance < AIRCRAFT_MAX_RANGE_KM):
                continue

            demand_score = get_route_demand_score(orig_airport['city'], dest_airport['city'])
            profitability_score = calculate_profitability_score(demand_score, distance)
            # Pass airports_clean_df to competition function
            competition_level = assess_competition_level(orig_airport['iata_code'], dest_airport['iata_code'], airports_clean_df)
            
            # Refined Business Logic: New Route Criteria
            current_demand_threshold = DEMAND_THRESHOLD_FOR_RECOMMENDATION
            current_profitability_threshold = MIN_PROFITABILITY_SCORE_FOR_RECOMMENDATION

            if competition_level == 'High':
                current_demand_threshold += 30
                current_profitability_threshold += 10
            elif competition_level == 'Medium':
                current_demand_threshold += 10

            if (demand_score >= current_demand_threshold and
                profitability_score >= current_profitability_threshold):
                
                route_info = {
                    'origin_iata': orig_airport['iata_code'],
                    'origin_city': orig_airport['city'],
                    'destination_iata': dest_airport['iata_code'],
                    'destination_city': dest_airport['city'],
                    'distance_km': round(distance, 2),
                    'demand_score': demand_score,
                    'profitability_score': profitability_score,
                    'competition_level': competition_level,
                    'origin_lat': orig_airport['latitude_deg'],
                    'origin_lon': orig_airport['longitude_deg'],
                    'dest_lat': dest_airport['latitude_deg'],
                    'dest_lon': dest_airport['longitude_deg']
                }
                # Pass only necessary arguments to flight simulator
                route_info['flights'] = simulate_flights_for_route(
                    orig_airport['city'], dest_airport['city'], distance
                )
                potential_new_routes.append(route_info)

    new_routes_df = pd.DataFrame(potential_new_routes).sort_values(
        by=['demand_score', 'profitability_score'], ascending=[False, False]
    )

    print(f"Identified {len(new_routes_df)} potential new routes.")
    print("\nTop 15 Potential New Routes for Indigo (by simulated demand & profitability):")
    display_df = new_routes_df[['origin_city', 'destination_city', 'distance_km', 'demand_score', 'profitability_score', 'competition_level']].head(15)
    # Add a 'No.' column for user selection in CLI
    display_df = display_df.reset_index(drop=True).reset_index().rename(columns={'index': 'No.'})
    print(display_df.to_string(index=False))

    # 5. Visualize Results on an Interactive Map
    print("\nCreating interactive map...")
    m = folium.Map(location=[20.5937, 78.9629], zoom_start=4)

    for idx, airport in airports_clean_df.iterrows():
        color = 'blue'
        icon = 'plane'
        if airport['iata_code'] in INDIGO_HUBS_IATA:
            color = 'darkblue'
            icon = 'star'
        folium.Marker(
            location=[airport['latitude_deg'], airport['longitude_deg']],
            popup=f"<b>{airport['name']} ({airport['iata_code']})</b><br>{airport['city']}, {airport['iso_country']}",
            icon=folium.Icon(color=color, icon=icon, prefix='fa')
        ).add_to(m)

    for idx, route in new_routes_df.head(25).iterrows():
        flight_details_str = "<br><b>Simulated Flights:</b><br>"
        if route['flights']:
            for flight in route['flights'][:3]:
                flight_details_str += (
                    f"- {flight['day']} {flight['departure_time']} ({flight['duration_min']} min) "
                    f"Est. ₹{flight['estimated_price_inr']}<br>"
                )
            if len(route['flights']) > 3:
                flight_details_str += "(... and more)<br>"
        else:
            flight_details_str += "No flights simulated.<br>"

        folium.PolyLine(
            locations=[
                [route['origin_lat'], route['origin_lon']],
                [route['dest_lat'], route['dest_lon']]
            ],
            color='red',
            weight=2.5,
            opacity=0.7,
            tooltip=(f"<b>{route['origin_city']} ({route['origin_iata']}) "
                     f"to {route['destination_city']} ({route['destination_iata']})</b><br>"
                     f"Distance: {route['distance_km']} km<br>"
                     f"Demand: {route['demand_score']}<br>"
                     f"Profitability: {route['profitability_score']}<br>"
                     f"Competition: {route['competition_level']}{flight_details_str}")
        ).add_to(m)

    map_output_path = 'indigo_new_routes_map.html'
    m.save(map_output_path)
    print(f"Interactive map saved to {map_output_path}")

    # Command Line Interface for "Choosing" Flights
    choose_flight_cli(new_routes_df.head(15)) # Pass only the top routes

    print("\nProject complete! Open the HTML file in your browser to see the map.")

def choose_flight_cli(routes_df):
    print("\n--- Choose a Route/Flight for Details ---")
    print("Enter the number of a recommended route to see its simulated flights.")
    print("Or type 'exit' to quit.")

    while True:
        try:
            choice_str = input("Enter route number (0-{}): ".format(len(routes_df) - 1))
            if choice_str.lower() == 'exit':
                break # Exit the main loop if user types 'exit'

            choice_idx = int(choice_str)
            if 0 <= choice_idx < len(routes_df):
                selected_route = routes_df.iloc[choice_idx]
                print(f"\n--- Flights for {selected_route['origin_city']} ({selected_route['origin_iata']}) "
                      f"to {selected_route['destination_city']} ({selected_route['destination_iata']}) ---")
                
                if selected_route['flights']:
                    while True: # Inner loop for filtering options
                        for i, flight in enumerate(selected_route['flights']):
                            print(f"  {i+1}. Day: {flight['day']}, Time: {flight['departure_time']}, "
                                  f"Duration: {flight['duration_min']} min, Price: ₹{flight['estimated_price_inr']}")
                        
                        # Updated prompt for clarity
                        filter_choice = input(
                            "To filter, type 'day' or 'price'. Type 'back' to choose another route, or 'exit' to quit: "
                        ).lower().strip() # .strip() removes any leading/trailing whitespace
                        
                        if filter_choice == 'price':
                            try:
                                max_price_input = input("Enter max price: ")
                                if max_price_input.strip() == '':
                                    max_price = float('inf')
                                else:
                                    max_price = float(max_price_input)
                                filtered_flights = [f for f in selected_route['flights'] if f['estimated_price_inr'] <= max_price]
                                print("\nFiltered Flights:")
                                if filtered_flights:
                                    for f in filtered_flights:
                                        print(f"  Day: {f['day']}, Time: {f['departure_time']}, Price: ₹{f['estimated_price_inr']}")
                                else:
                                    print("No flights found matching price filter.")
                            except ValueError:
                                print("Invalid price entered. Please enter a a number.") # Corrected error message
                        elif filter_choice == 'day':
                            req_day = input("Enter desired day (Mon/Tue/Wed/Thu/Fri/Sat/Sun): ")
                            filtered_flights = [f for f in selected_route['flights'] if f['day'].lower() == req_day.lower()]
                            print("\nFiltered Flights:")
                            if filtered_flights:
                                for f in filtered_flights:
                                    print(f"  Day: {f['day']}, Time: {f['departure_time']}, Price: ₹{f['estimated_price_inr']}")
                            else:
                                print("No flights found for that day.")
                        elif filter_choice == 'back':
                            break # Break out of the inner filtering loop to go back to route selection
                        elif filter_choice == 'exit':
                            sys.exit("\nExiting the Flight Planner. Goodbye!") # Exit the entire script
                        else:
                            # --- NEW: Specific error message for invalid filter options ---
                            print("Invalid option. Please type 'day', 'price', 'back', or 'exit'.")
                else:
                    print("No simulated flights available for this route.")
                
            else:
                print("Invalid route number. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a number for route selection, or 'exit'.") # Adjusted message for initial prompt
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()