# airports_data.py
import pandas as pd
from constants import RELEVANT_COUNTRIES # Import RELEVANT_COUNTRIES from constants

def load_and_clean_airports(file_path='airports.csv'):
    """
    Loads airport data from a CSV, filters it by relevant countries and airport types,
    and selects/cleans necessary columns.
    """
    print("Loading airport data...")
    airports_df = pd.read_csv(file_path)

    # Filter for relevant airport types and countries
    filtered_airports = airports_df[
        (airports_df['iso_country'].isin(RELEVANT_COUNTRIES)) &
        (airports_df['type'].isin(['large_airport', 'medium_airport']))
    ].copy()

    # Select relevant columns and drop rows with missing IATA codes
    # IMPORTANT: If you edited airports.csv to rename 'municipality' to 'city', this is correct.
    # Otherwise, change 'city' to 'municipality' below and then rename it after this line.
    airports_clean_df = filtered_airports[[
        'name', 'iata_code', 'city', 'iso_country', 'latitude_deg', 'longitude_deg'
    ]].dropna(subset=['iata_code'])

    # If you did NOT edit the CSV, uncomment and use this line instead of the above block:
    # airports_clean_df = filtered_airports[[
    #     'name', 'iata_code', 'municipality', 'iso_country', 'latitude_deg', 'longitude_deg'
    # ]].dropna(subset=['iata_code']).rename(columns={'municipality': 'city'})

    print(f"Loaded and filtered {len(airports_clean_df)} relevant airports.")
    print(airports_clean_df.head())
    return airports_clean_df