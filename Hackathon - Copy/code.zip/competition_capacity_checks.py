# competition_capacity_checks.py
import random
from constants import INDIGO_HUBS_IATA, CONGESTED_AIRPORTS_IATA # Import constants

def assess_competition_level(origin_iata, dest_iata, all_airports_clean_df):
    """
    Simulates the competition level on a route based on predefined
    highly competitive routes.
    """
    highly_competitive_routes = [
        tuple(sorted(('DEL', 'BOM'))), tuple(sorted(('BOM', 'BLR'))),
        tuple(sorted(('DEL', 'BLR'))), tuple(sorted(('DEL', 'MAA'))),
        tuple(sorted(('BOM', 'MAA'))), tuple(sorted(('BLR', 'MAA'))),
        tuple(sorted(('DEL', 'HYD'))), tuple(sorted(('BOM', 'HYD'))),
        tuple(sorted(('BLR', 'HYD'))), tuple(sorted(('DEL', 'CCU'))),
        tuple(sorted(('DEL', 'DXB'))), tuple(sorted(('BOM', 'DXB')))
    ]

    current_route_pair = tuple(sorted((origin_iata, dest_iata)))

    if current_route_pair in highly_competitive_routes:
        return 'High'
    elif (origin_iata in INDIGO_HUBS_IATA and dest_iata in INDIGO_HUBS_IATA) or \
         (origin_iata in INDIGO_HUBS_IATA and dest_iata not in all_airports_clean_df[all_airports_clean_df['iso_country'] == 'IN']['iata_code'].tolist()): # Hub to International
        return 'Medium'
    else:
        return 'Low'

def check_airport_capacity(iata_code):
    """
    Simulates airport slot/handling capacity.
    """
    if iata_code in CONGESTED_AIRPORTS_IATA:
        return random.random() > 0.4 # 60% chance of being available even if congested
    else:
        return True