# demand_profit_calcs.py
from constants import CITY_DEMAND_SCORES # Import CITY_DEMAND_SCORES from constants

def get_route_demand_score(origin_city, dest_city):
    """
    Calculates a simple demand score for a route based on predefined city demand factors.
    """
    origin_factor = CITY_DEMAND_SCORES.get(origin_city, 20)
    dest_factor = CITY_DEMAND_SCORES.get(dest_city, 20)
    return origin_factor + dest_factor

def calculate_profitability_score(demand_score, distance_km, base_cost_per_km=0.04, revenue_factor=0.8):
    """
    Simulates a basic profitability score for a route.
    """
    simulated_revenue = demand_score * revenue_factor * (distance_km / 1000)
    simulated_cost = distance_km * base_cost_per_km
    profit = simulated_revenue - simulated_cost
    return max(0, round(profit, 2))